function openPlans(){
    window.location.href="./plans.html";
}