const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8080 });


function formatDate(date) {
  const options = { year: 'numeric', month: 'short', day: '2-digit' };
  return date.toLocaleDateString('en-US', options);
}
const currentDate = new Date();
const formattedDate = formatDate(currentDate);

let dataList = [{"formattedDate":formattedDate,"data_list":[]}];


wss.on('connection', function connection(ws) {
  // 当有客户端连接时
  ws.on('message', function incoming(message) {
    const messageStr = message.toString('utf8');
    const data = JSON.parse(messageStr);
    if(data!="" && data!="sa"){
      if(data.type=="add"){
        dataList.push(data.data); // 将收到的数据添加到dataList中
      }else if(data.type=="update"){
        dataList=data.data;
      }
    }

    // 实时广播最新的dataList给所有客户端
    wss.clients.forEach(function each(client) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(dataList));
      }
    });
  });
}); 