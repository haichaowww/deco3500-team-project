var data_list=[{
    "id":1,
    "name":'Brisbane City Hall',
    "src":"./image/066934.jpg",
    "content":'64 Adelaide St, Brisbane City QLD 4000',
    "button":"Add by Kevin",
    "time":"1PM  15～29",
    "txImg":"./image/IMG_2647.JPG"
},{
    "id":2,
    "name":'Gallery of Modern Art',
    "src":"./image/Ex-Venue-Hero-Pyramid-Plaza-2.jpeg",
    "content":'Stanley Pl, South Brisbane QLD 4101',
    "button":"Add by Sonia",
    "time":"3PM  15～29",
    "txImg":"./image/IMG_2649.JPG"
},{
    "id":3,
    "name":'The Wheel of Brisbane',
    "src":"./image/WHEEL-OF-BRISBANE-BONUS-BY-GREEN-CABS.jpeg",
    "content":'Russell St, South Brisbane QLD 4101',
    "button":"Add by Haichao",
    "time":"7PM  19～13",
    "txImg":"./image/IMG_2646.JPG"
},{
    "id":4,
    "name":'Story Bridge',
    "src":"./image/2.png",
    "content":'State Route 15, New Farm QLD 4169',
    "button":"Add by Haichao",
    "time":"9PM  17～13",
    "txImg":"./image/IMG_2646.JPG"
},{
    "id":5,
    "name":'Long Pine Koala Sanctuary',
    "src":"./image/1.jpeg",
    "content":'708 Jesmond Rd, Fig Tree Pocket QLD 4069',
    "button":"Add by Xixi",
    "time":"9AM  17～29",
    "txImg":"./image/IMG_2648.JPG"
},{
    "id":6,
    "name":'The University of Queensland',
    "src":"./image/images.jpeg",
    "content":'St Lucia QLD 4072',
    "button":"Add by Yuteng",
    "time":"2PM  29～17",
    "txImg":"./image/IMG_2645.JPG"
}];

// var data_list=['Brisbane City Hall','Brisbane sign','Queensland Museum','Story Bridge','University of Queensland'];
var fetch_dataList=[];

function changeLocal(){
    var searchText=$("#searchText").val();
    var now_data_list=[];
    data_list.forEach(data=>{
        if(data.name.toLowerCase().includes(searchText.toLowerCase())){
            now_data_list.push(data);
        }
    });
    createData(now_data_list);
}

const ws = new WebSocket('ws://localhost:8080');

ws.onopen = function(event) {
    console.log('WebSocket连接已打开');
    // 在连接打开时发送数据示例
    sendDataToServer("sa");
    createData(data_list);
};

ws.onmessage = function(event) {
    const dataList = JSON.parse(event.data);
    console.log(dataList);
    fetch_dataList=dataList;
};

function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}


function add(id){
    var day_list=JSON.parse(window.localStorage.getItem("day"));
    const day = getQueryParam('day'); 
    // var now_data=day_list[day-1];
    // var now_data_list=now_data.data_list;
    // now_data_list.push({"name":data});
    // window.localStorage.setItem("day",JSON.stringify(day_list));
    var da_list=[];
    fetch_dataList.forEach(fd=>{
        if(fd.formattedDate==day){
           var now_data_list=fd.data_list;
           var now_data={};
           data_list.forEach(data=>{
               if(data.id==id){
                   now_data=data;
               }
           });
           now_data_list.push(now_data);
           da_list.push({"formattedDate":fd.formattedDate,"data_list":now_data_list})
        }else{
            da_list.push(fd);
        }
    });
    // console.log(fetch_dataList);
    // console.log(da_list);
   sendDataToServer({"type":"update","data":da_list});
//    alert("Add successully!");
   window.location.href="./plans.html";
}

function sendDataToServer(data) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    } else {
        alert('The WebSocket connection is not open and data cannot be sent.');
    }
  }

function createData(now_data_list){
    var str="";
    now_data_list.forEach(data=>{
        str+=`
            <div class="address_data">
                <div class="img_box">
                    <img src="${data.src}"/>
                </div>
                <div class="tt_box">
                    <h2>${data.name}</h2>
                    <p>${data.content}</p>
                    <p>
                        <svg t="1728379786995" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1764" width="30" height="30"><path d="M512 512m-480 0a480 480 0 1 0 960 0 480 480 0 1 0-960 0Z" fill="#2F77F1" p-id="1765"></path><path d="M728 560H488c-13.2 0-24-10.8-24-24V344c0-13.2 10.8-24 24-24s24 10.8 24 24v168h216c13.2 0 24 10.8 24 24s-10.8 24-24 24z" fill="#AFFCFE" p-id="1766"></path></svg>
                        ${data.time}
                        <svg t="1728379893248" class="icon" viewBox="0 0 1161 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2858" width="30" height="30"><path d="M781.833075 1023.972803H440.345543a440.075272 440.075272 0 1 1 399.450324-624.247368 314.460894 314.460894 0 0 1-57.962792 624.247368zM440.345543 220.312747a363.584784 363.584784 0 0 0 0 727.169569h341.487532a238.480343 238.480343 0 0 0 87.964061-460.047789 441.94504 441.94504 0 0 1-13.853277 241.624952 38.304736 38.304736 0 1 1-72.241016-25.496829 363.839753 363.839753 0 0 0-343.3573-483.249903z" fill="#0071BC" p-id="2859"></path><path d="M840.050835 399.725435a313.610999 313.610999 0 0 1 155.27569 77.425371A276.385629 276.385629 0 0 0 551.001782 157.930505a441.94504 441.94504 0 0 1 289.049053 241.79493zM576.838568 107.616762a38.160254 38.160254 0 0 1-27.026639-11.218605l-30.171247-30.171248a38.245244 38.245244 0 1 1 54.053277-54.053278l30.171248 30.171248a38.245244 38.245244 0 0 1-27.026639 65.271883zM952.066905 121.045092a38.245244 38.245244 0 0 1-31.786047-59.492602l21.587315-32.550952a38.304736 38.304736 0 1 1 63.742073 42.494716l-21.587315 32.550952a38.245244 38.245244 0 0 1-31.956026 16.997886z" fill="#65C8D0" p-id="2860"></path><path d="M1120.855914 430.066662h-2.97463l-45.894292-3.484567a38.35573 38.35573 0 1 1 5.86427-76.490488l45.894293 3.484567a38.270741 38.270741 0 0 1-2.889641 76.490488z" fill="#65C8D0" p-id="2861"></path></svg>
                    </p>
                    <div class="address_add_box" onclick="add('${data.id}')">
                        <img style="width: 40px;height: 40px;border-radius: 30px;" src='${data.txImg}'/>
                        <span>
                            ${data.button}
                        </span>
                    </div>
                </div>
            </div>
        `;
    });
    $("#address_data_list").html(str);
}

// $(function(){
// });