var data_list=[];
var i=1;
function backIndex(){
    window.location.href="./index.html";
}

function formatDate(date) {
    const options = { year: 'numeric', month: 'short', day: '2-digit' };
    return date.toLocaleDateString('en-US', options);
}

function openMap(){
    window.location.href="./map.html";
}

const ws = new WebSocket('ws://172.20.10.6:8080');

ws.onopen = function(event) {
  console.log('WebSocket连接已打开');
  // 在连接打开时发送数据示例
  sendDataToServer("");
};
ws.onmessage = function(event) {
    const dataList = JSON.parse(event.data);
    console.log(dataList);
    data_list=dataList;
    createData();
};


ws.onerror = function(error) {
  console.error('WebSocket连接发生错误:', error);
};

ws.onclose = function(event) {
  console.log('WebSocket连接已关闭');
};

function sendDataToServer(data) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  } else {
    console.error('WebSocket连接未打开，无法发送数据');
  }
}


function createData(){
    var str="";
    var str2="";
    var i=0;
    data_list.forEach((data,index)=>{
        str+=`
            <div class="details_row">
                <h3>DAY ${index+1}</h3>
                <p>${data.formattedDate}</p>
            </div>
        `;
        str2+=`
            <div class="day_data">
                <h2>DAY ${index+1}</h2>
                <p>${data.formattedDate}</p>
                `;
        data.data_list.forEach(now_data=>{
            str2+=`
                <div class="address_data">
                    <div class="img_box">
                        <img src="${now_data.src}"/>
                    </div>
                    <div class="tt_box">
                        <h2>${now_data.name}</h2>
                        <p>${now_data.content}</p>
                        <p>
                            <svg t="1728379786995" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1764" width="30" height="30"><path d="M512 512m-480 0a480 480 0 1 0 960 0 480 480 0 1 0-960 0Z" fill="#2F77F1" p-id="1765"></path><path d="M728 560H488c-13.2 0-24-10.8-24-24V344c0-13.2 10.8-24 24-24s24 10.8 24 24v168h216c13.2 0 24 10.8 24 24s-10.8 24-24 24z" fill="#AFFCFE" p-id="1766"></path></svg>
                            ${now_data.time}
                            <svg t="1728379893248" class="icon" viewBox="0 0 1161 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2858" width="30" height="30"><path d="M781.833075 1023.972803H440.345543a440.075272 440.075272 0 1 1 399.450324-624.247368 314.460894 314.460894 0 0 1-57.962792 624.247368zM440.345543 220.312747a363.584784 363.584784 0 0 0 0 727.169569h341.487532a238.480343 238.480343 0 0 0 87.964061-460.047789 441.94504 441.94504 0 0 1-13.853277 241.624952 38.304736 38.304736 0 1 1-72.241016-25.496829 363.839753 363.839753 0 0 0-343.3573-483.249903z" fill="#0071BC" p-id="2859"></path><path d="M840.050835 399.725435a313.610999 313.610999 0 0 1 155.27569 77.425371A276.385629 276.385629 0 0 0 551.001782 157.930505a441.94504 441.94504 0 0 1 289.049053 241.79493zM576.838568 107.616762a38.160254 38.160254 0 0 1-27.026639-11.218605l-30.171247-30.171248a38.245244 38.245244 0 1 1 54.053277-54.053278l30.171248 30.171248a38.245244 38.245244 0 0 1-27.026639 65.271883zM952.066905 121.045092a38.245244 38.245244 0 0 1-31.786047-59.492602l21.587315-32.550952a38.304736 38.304736 0 1 1 63.742073 42.494716l-21.587315 32.550952a38.245244 38.245244 0 0 1-31.956026 16.997886z" fill="#65C8D0" p-id="2860"></path><path d="M1120.855914 430.066662h-2.97463l-45.894292-3.484567a38.35573 38.35573 0 1 1 5.86427-76.490488l45.894293 3.484567a38.270741 38.270741 0 0 1-2.889641 76.490488z" fill="#65C8D0" p-id="2861"></path></svg>
                        </p>
                        <div class="address_add_box">
                            <img style="width: 40px;height: 40px;border-radius: 30px;" src='${now_data.txImg}'/>
                            <span>
                                ${now_data.button}
                            </span>
                        </div>
                    </div>
                    <div class="close_box" onclick="deleteItem('${now_data.name}','${i}')">
                     <svg t="1728388735002" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3874" width="30" height="30"><path d="M568.6 512l346.6-346.6c15.6-15.6 15.6-40.9 0-56.6-15.6-15.6-40.9-15.6-56.6 0L512 455.4 165.4 108.9c-15.6-15.6-40.9-15.6-56.6 0-15.6 15.6-15.6 40.9 0 56.6L455.4 512 108.9 858.6c-15.6 15.6-15.6 40.9 0 56.6 7.8 7.8 18 11.7 28.3 11.7s20.5-3.9 28.3-11.7L512 568.6l346.6 346.6c7.8 7.8 18 11.7 28.3 11.7s20.5-3.9 28.3-11.7c15.6-15.6 15.6-40.9 0-56.6L568.6 512z" fill="#333333" p-id="3875"></path></svg>
                    </div>
                </div>
            `;
            i++;
        });
       
        str2+=`
                <div class="day_data_add">
                    <img onclick="openAddress('${data.formattedDate}')" src="./image/di_add.png"/>
                </div>
                
            </div>
        `;
    });
    $("#details_list").html(str);
    $("#day_data_list").html(str2);
}

function openAddress(day){
    window.localStorage.setItem("day",JSON.stringify(data_list));
    window.location.href="explore.html?day="+day;
}

//新增(socket)
function add(){
    var currentDate = new Date();
    currentDate.setMinutes(currentDate.getMinutes() + (data_list.length*1440));
    const formattedDate = formatDate(currentDate);
    sendDataToServer({"type":"add","data":{"formattedDate":formattedDate,"data_list":[]}});
}

//删除(socket)
function deleteItem(name,id){
    var i=0;
    var now_data_list=[];
    data_list.forEach((data,index)=>{
        var now_data=data;
        var now_data_item=[];
        data.data_list.forEach(nd=>{
            if(i!=id){
                now_data_item.push(nd);
            }
            i++;
        });
        now_data.data_list=now_data_item;
        now_data_list.push(now_data);
    });
    sendDataToServer({"type":"update","data":now_data_list});
    
}

// $(function(){
//     var now_day=window.localStorage.getItem("day");
//     if(now_day){
//         now_day=JSON.parse(now_day);
//         // console.log(now_day);
//         data_list=now_day;
//     }else{
//         const currentDate = new Date();
//         const formattedDate = formatDate(currentDate);
//         data_list.push({"formattedDate":formattedDate,"data_list":[]});
//     }
    
// });

